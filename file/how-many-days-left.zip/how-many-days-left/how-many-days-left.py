# 距離比賽還有...天!

from datetime import datetime, timedelta

# 現在日期
current = datetime.now()

# 目標日期
target = datetime(2024, 2, 24) + timedelta(1)

# 計算距離比賽還有的天數
days_remaining = (target - current).days

# 計算距離比賽還有的月數
months_remaining = (target.year - current.year) * 12 + target.month - current.month

# 天
print(f"距離{target.date()}還有 {days_remaining} 天")

# 月
print(f"距離{target.date()}還有 {months_remaining} 個月")

# 禮拜
m, d = divmod(days_remaining, 7)
print(f"距離{target.date()}還有 {m} 個禮拜 又 {d} 天")

input()