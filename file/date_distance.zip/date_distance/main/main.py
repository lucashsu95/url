from tkinter import *
import howManyDateLeft

# 創建主視窗
root = Tk()

date = howManyDateLeft.main(2024,3,28)


label = Label(root, text=date) # 加文字
label.pack(pady=10,padx=80)  # 設定元素的外邊距

# 啟動主視窗的迴圈
root.mainloop()
